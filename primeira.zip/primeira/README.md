mkdir primeira
cd primeira/

mkdir "Basic Set"
cd Basic\ Set/
mkdir 2013
mkdir 2015

cd 2013/

mkdir "LEGO Creative Bucket"
cd LEGO\ Creative\ Bucket/
touch "Bricks"
code Bricks
touch "Bricks Special"
code Bricks\ Special
touch "Plates Special"
code Plates\ Special
cd ..

mkdir "Monster Trucks"
cd Monster\ Trucks/
touch "Flags, Signs, Plastics and Cloth"
code Flags\,\ Signs\,\ Plastics\ and\ Cloth
touch "Tiles Special"
code Tiles\ Special"
touch "Windscreens and Fuselage"
code Windscreens\ and\ Fuselage
cd ..
cd ..

cd 2015/

mkdir "Creative Bricks"
cd Creative\ Bricks/
touch "Bricks Curved"
code Bricks\ Curved
touch "Plates Round and Dishes"
code Plates\ Round\ and\ Dishes
touch "Transportation - Sea and Air"
code Transportation\ -\ Sea\ and\ Air
cd ..

mkdir "Creative Building Box"
cd Creative\ Building\ Box/
touch "Wheels and Tyres"
code Wheels\ and\ Tyres
touch "Bricks Sloped"
code Bricks\ Sloped
touch Plates
code Plates
cd ..
cd ..
cd ..

mkdir "Sculptures"
cd Sculptures/

mkdir 2008
cd 2008/

mkdir "Volkswagen Beetle (VW Beetle)"
cd Volkswagen\ Beetle\ \(VW\ Beetle\)/
touch "String, Bands and Reels"
code String\,\ Bands\ and\ Reels
touch "Bars, Ladders and Fences"
code Bars\,\ Ladders\ and\ Fences
touch "Hinges, Arms and Turntables"
code Hinges\,\ Arms\ and\ Turntables
cd ..

mkdir "Taj Mahal"
cd Taj\ Mahal/
touch Bricks
code Bricks
touch "Plates Angled"
code Plates\ Angled
touch "Technic Pins"
code Technic\ Pins
cd ..
cd ..

mkdir 2010
cd 2010/

mkdir "Shuttle Adventure"
cd Shuttle\ Adventure/
touch "Transportation - Land"
code Transportation\ -\ Land
touch "Minifig Accessories"
code Minifig\ Accessories
touch "Bricks Round and Cones"
code Bricks\ Round\ and\ Cones
cd ..

mkdir "Tower Bridge"
cd Tower\ Bridge/
touch Bricks
code Bricks
touch "Technic Bricks"
code Technic\ Bricks
touch "Windows and Doors"
code Windows\ and\ Doors
cd ..
cd ..
cd ..

mkdir "Harry Potter"
cd Harry\ Potter/

mkdir 2004
cd 2004/

mkdir "Knight Bus - Mini"
cd Knight\ Bus\ -\ Mini/
touch Bricks
code Bricks
touch Plates
code Plates
touch "Wheels and Tyres"
code Wheels\ and\ Tyres
cd ..

mkdir "Hogwarts Express (2nd edition)"
cd Hogwarts\ Express\ \(2nd\ edition\)/
touch "Tiles Printed"
code Tiles\ Printed
touch "Minifig Accessories"
code Minifig\ Accessories
touch "Bars, Ladders and Fences"
code Bars\,\ Ladders\ and\ Fences
cd ..
cd ..

mkdir 2010
cd 2010/

mkdir "Freeing Dobby"
cd Freeing\ Dobby/
touch "Bricks Special"
code Bricks\ Special
touch "Plants and Animals"
code Plants\ and\ Animals
touch Minifigs
code Minifigs
cd ..

mkdir "Quidditch Match"
cd Quidditch\ Match/
touch "Bricks Round and Cones"
code Bricks\ Round\ and\ Cones
touch Tiles
code Tiles
touch "Tubes and Hoses"
code Tubes\ and\ Hoses
cd ..
cd ..
cd ..
cd ..